package supermarket.pricing;

import junit.framework.Assert;
import org.junit.Test;

public class TestClass {
    @Test
    public void testAcheterPrendre(){
        Produit soda = new Produit("Chocolat",1,Unite.NOMBRE,true,2,3);
        float prix = soda.prix(9);
        Assert.assertEquals(6.0f, prix);
    }
    
    @Test
    public void testAcheterPrendre2(){
        Produit chocolat = new Produit("Chocolat",1,Unite.NOMBRE,true,2,3);
        float prix = chocolat.prix(10);
        Assert.assertEquals(7.0f, prix);
    }
    
    @Test
    public void testZeroProduit (){
        Produit eau = new Produit("Eau",1,Unite.NOMBRE);
        float prix = eau.prix(0);
        Assert.assertEquals(0.0f, prix);
    }
    
    @Test
    public void testGrammeKg(){
        Produit tomate = new Produit("Tomate",2,Unite.KG);
        float prix = tomate.prix(5);
        Assert.assertEquals(10.0f, prix);
        
    }
    
    @Test
    public void TestQuantiteNombre(){
        Produit lait = new Produit("Lait",2,Unite.NOMBRE);
        float prix = lait.prix(3);
        Assert.assertEquals(6.0f, prix);
        
    }
}