package supermarket.pricing;

class Produit
{   
    String nom;
    int prix_unite; 
    Unite unite; 
    boolean offre_groupe; //Is this product eligible for a group offer?
    int acheter;
    int prendre; //If so..what are the values of buy and get..

    public Produit(String nom, int prix_unite, Unite unite) {
        this.nom = nom;
        this.prix_unite = prix_unite;
        this.unite = unite;
        this.offre_groupe = false;
    }

    public Produit(String nom, int prix_unite, Unite unite, boolean offre_groupe) {
        this.nom = nom;
        this.prix_unite = prix_unite;
        this.unite = unite;
        this.offre_groupe = offre_groupe;
    }
    
    public Produit(String nom, int prix_unite, Unite unite,boolean offre_groupe, int acheter, int prendre) {
        this.nom = nom;
        this.prix_unite = prix_unite;
        this.unite = unite;
        this.offre_groupe = offre_groupe;
        this.acheter = acheter;
        this.prendre = prendre;
    }
    
    public float prix(float quantite)
    {
        float prix = prix_unite * quantite;
        
        if(offre_groupe)
        {
            if(quantite % prendre == 0)
            {
                prix = acheter * prix_unite * quantite / prendre;
            }else
            {
                prix = (acheter * prix_unite * (quantite -(quantite % prendre)) / prendre) + ((quantite % prendre) * prix_unite);
            }
                
        }
        return prix;
    }
}
