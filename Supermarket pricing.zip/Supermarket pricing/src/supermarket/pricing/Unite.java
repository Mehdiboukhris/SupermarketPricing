package supermarket.pricing;

public enum Unite {
    NOMBRE,
    GRAM,
    KG;
}
